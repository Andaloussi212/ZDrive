import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ConfigReader {
    public static SiteConfig lireConfig(String cheminFichier) {
        try {

        File fichier = new File(cheminFichier);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        DocumentBuilder builder = factory.newDocumentBuilder();

        Document doc = builder.parse(fichier);

        Element site = (Element) doc.getElementsByTagName("site").item(0);

        String portTexte = site.getElementsByTagName("port").item(0).getTextContent().trim();
        int port = Integer.parseInt(portTexte);

        String documentRoot = site.getElementsByTagName("DocumentRoot").item(0).getTextContent().trim();
        String defaultIndex = site.getElementsByTagName("DefaultIndex").item(0).getTextContent().trim();
        String accessLog = site.getElementsByTagName("Acceslog").item(0).getTextContent().trim();
        String errorLog = site.getElementsByTagName("Errorlog").item(0).getTextContent().trim();

        return new SiteConfig(port, documentRoot, defaultIndex, accessLog, errorLog);

        } catch (Exception e) {
            System.out.println("Erreur de lecture xml : " + e.getMessage());
            return null;
        }
    }

    public static ArrayList<SiteConfig> lireConfigs(String dossierConf) {
        ArrayList<SiteConfig> configs = new ArrayList<>();

        File dossier = new File(dossierConf);
        File[] fichiers = dossier.listFiles();

        if (fichiers == null) {
            System.out.println("Dossier de configuration introuvable");
            return configs;
        }

        for (File fichier : fichiers) {
            if (fichier.isFile() && fichier.getName().endsWith(".conf")) {
                SiteConfig config = lireConfig(fichier.getPath());
                if (config != null) {
                    configs.add(config);
                }
            }
        }
        return configs;
    }
}
