import java.io.FileWriter;
import java.time.LocalDateTime;

public class WebLogger {

  public static void logAcces(String cheminLog, String message) {
    ecrire(cheminLog, "[ACCESS] " + LocalDateTime.now() + " " + message);
  }

  public static void logError(String cheminLog, String message) {
    ecrire(cheminLog, "[ERROR] " + LocalDateTime.now() + " " + message);
  }

  private static void ecrire(String cheminLog, String message) {
    try {
      FileWriter fw = new FileWriter(cheminLog, true);
      fw.write(message + "\n");
      fw.close();
    } catch (Exception e) {
      System.out.println("Erreur écriture log : " + e.getMessage());
    }
  }
}
