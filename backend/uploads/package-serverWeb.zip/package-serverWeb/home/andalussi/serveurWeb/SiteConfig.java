
public class SiteConfig {
  private int port;
  private String documentRacine;
  private String fichierParDefaut;
  private String cheminLogs;
  private String cheminLogErreur;

  public SiteConfig(int p, String dr, String fd, String cl, String cle) {
    this.port = p;
    this.documentRacine = dr;
    this.fichierParDefaut = fd;
    this.cheminLogs = cl;
    this.cheminLogErreur = cle;
  }

  public int getPort() {
    return this.port;
  }

  public String getDocumentRacine() {
    return this.documentRacine;
  }

  public String getFichierDefaut() {
    return this.fichierParDefaut;
  }

  public String getCheminLog() {
    return this.cheminLogs;
  }

  public String getCheminLogErreur() {
    return this.cheminLogErreur;
  }
}
