#!/bin/bash

cd "$HOME/serveurWeb"
java -cp "$HOME/serveurWeb/bin" HttpServer

