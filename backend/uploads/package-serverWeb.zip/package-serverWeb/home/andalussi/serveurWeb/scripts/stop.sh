#!/bin/bash

PID_FILE="$HOME/serveurWeb/run/myweb.pid"

if [ -f "$PID_FILE" ]; then
  kill $(cat "$PID_FILE")
  rm "$PID_FILE"
  echo "Serveur arrêté"
else
  echo "Aucun fichier PID trouvé"
fi
