import java.io.File;

public class StatusPage {
  public static String generer() {
    Runtime runtime = Runtime.getRuntime();

    long memoireLibre = runtime.freeMemory();
    long memoireMax = runtime.maxMemory();

    File disque = new File("/");
    long espaceLibre = disque.getFreeSpace();

    int nbProcessus = compterProcessus();

    String html = "<html><body>";
    html += "<h1>Status du serveur</h1>";
    html += "<p>Memoire libre :  " + memoireLibre + " octets</p>";
    html += "<p>Memoire max : " + memoireMax + " octets</p>";
    html += "<p>Espace disque libre : " + espaceLibre + "octets</p>";
    html += "<p>Nombres de processus : " + nbProcessus + "</p>";
    html += "</body></html>";

    return html;
  }

  private static int compterProcessus() {
    try {
      File proc = new File("/proc");
      File[] fichiers = proc.listFiles();

      int compteur = 0;
      for (File fichier : fichiers) {
        if (fichier.isDirectory() && estNombre(fichier.getName())) {
          compteur ++;
        }
      }
      return compteur;
    } catch(Exception e) {
      return -1;
    }
  }

  private static boolean estNombre(String texte) {
    for (int i = 0; i < texte.length(); i++) {
      if (!Character.isDigit(texte.charAt(i))) {
        return false;
      }
    }
    return true;
  }
}
