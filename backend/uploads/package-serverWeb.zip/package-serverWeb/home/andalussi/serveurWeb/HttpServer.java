import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.zip.GZIPOutputStream;

public class HttpServer {
  public static void main(String[] args) {
    String home = System.getProperty("user.home");
    String dossierConf = home + "/serveurWeb/conf.d";
    creerPid();

    ArrayList<SiteConfig> configs = ConfigReader.lireConfigs(dossierConf);

    if (configs.isEmpty()) {
      System.out.println("Aucune configuration trouvée");
      return;
    }

    for (SiteConfig config : configs) {
      Thread thread = new Thread(() -> demarrerSite(config));
      thread.start();
    }
  }

  public static void demarrerSite(SiteConfig config) {
    String home = System.getProperty("user.home");
    try {
      ServerSocket serveur = new ServerSocket(config.getPort());

      System.out.println("Serveur démarré sur le port " + config.getPort());
      System.out.println("DocumentRoot : " + config.getDocumentRacine());

      while (true) {
        Socket client = serveur.accept();
        System.out.println("Client connecté : " + client.getInetAddress());

        BufferedReader entree = new BufferedReader(new InputStreamReader(client.getInputStream()));
        String premiereLigne = entree.readLine();

        String ifModifiedSince = null;
        String ligneHeader = entree.readLine();

        while (ligneHeader != null && !ligneHeader.equals("")) {
          if (ligneHeader.startsWith("If-Modified-Since:")) {
            ifModifiedSince = ligneHeader.substring("If-Modified-Since:".length()).trim();
          }

          ligneHeader = entree.readLine();
        }

        System.out.println("Requête reçue : " + premiereLigne);

        String[] morceaux = premiereLigne.split(" ");
        String chemindDemande = morceaux[1];

        if (chemindDemande.equals("/")) {
          chemindDemande = "/" + config.getFichierDefaut();
        }

        if (chemindDemande.equals("/status")) {
          String message = StatusPage.generer();

          OutputStream sortie = client.getOutputStream();
          String reponse = "HTTP/1.1 200 OK\r\n";
          reponse += "Date: " + dateHttp() + "\r\n";
          reponse += "Server: MiniJavaServer\r\n";
          reponse += "Content-Type:  text/html\r\n";
          reponse += "Content-Length: " + message.getBytes().length + "\r\n";
          reponse += "\r\n";
          reponse += message;

          sortie.write(reponse.getBytes());

          WebLogger.logAcces(config.getCheminLog(), client.getInetAddress() + " /status 200");

          client.close();
          continue;
        }

        System.out.println("Chemin demandé : " + chemindDemande);

        String baseServeur = home + "/serveurWeb";
        File fichierDemande = new File(baseServeur + "/" + config.getDocumentRacine() + chemindDemande);

        File racine = new File(baseServeur + "/" + config.getDocumentRacine());

        String cheminRacine = racine.getCanonicalPath();
        String cheminFichier = fichierDemande.getCanonicalPath();

        if(!cheminFichier.startsWith(cheminRacine)) {
          OutputStream sortie = client.getOutputStream();

          String message = "<html><body><h1>403 Forbidden</h1></body></html>";
          String reponse = "HTTP/1.1 403 Forbidden\r\n";
          reponse += "Date: " + dateHttp() + "\r\n";
          reponse += "Server: MiniJavaServer\r\n";
          reponse += "Content-Type:  text/html\r\n";
          reponse += "Content-Length: " + message.getBytes().length + "\r\n";
          reponse += "\r\n";
          reponse += message;

          sortie.write(reponse.getBytes());

          WebLogger.logError(config.getCheminLogErreur(), client.getInetAddress() + " " + chemindDemande + " 403 acces interdit");

          client.close();
          continue;
        }

        System.out.println("Fichier réel : " + fichierDemande.getPath());
        System.out.println("Existe : " + fichierDemande.exists());

        OutputStream sortie = client.getOutputStream();

        if (fichierDemande.exists() && fichierDemande.isDirectory()) {
          File fichierIndex = new File(fichierDemande, config.getFichierDefaut());

          if (fichierIndex.exists() && fichierIndex.isFile()) {
            fichierDemande = fichierIndex;
          } else {
            String message = genererListeDossier(fichierDemande, chemindDemande);

            String reponse = "HTTP/1.1 200 OK\r\n";
            reponse += "Date: " + dateHttp() + "\r\n";
            reponse += "Server: MiniJavaServer\r\n";
            reponse += "Content-Type:  text/html\r\n";
            reponse += "Content-Length: " + message.getBytes().length + "\r\n";
            reponse += "\r\n";
            reponse += message;

            sortie.write(reponse.getBytes());
            WebLogger.logAcces(config.getCheminLog(), client.getInetAddress() + " " + chemindDemande + " 200 liste dossier" );

            client.close();
            continue;
          }
        }

        if (fichierDemande.exists() && fichierDemande.isFile()) {
          if (ifModifiedSince != null && !estHtml(fichierDemande) && fichierNonModifie(fichierDemande, ifModifiedSince)) {
            String reponse = "HTTP/1.1 304 Not Modified\r\n";
            reponse += "Date: " + dateHttp() + "\r\n";
            reponse += "Server: MiniJavaServer\r\n";
            reponse += "ETag: " + calculerEtag(fichierDemande) + "\r\n";
            reponse += "Last-Modified: " + dateModificationHttp(fichierDemande) + "\r\n";
            reponse += "\r\n";

            sortie.write(reponse.getBytes());
            WebLogger.logAcces(config.getCheminLog(), client.getInetAddress() + " " + chemindDemande + " 304");
            client.close();
            continue;
          }
          byte[] contenu = Files.readAllBytes(fichierDemande.toPath());
          boolean gzip = doitGzip(fichierDemande);

          if(estHtml(fichierDemande)) {
            String html = new String(contenu, StandardCharsets.UTF_8);
            html = traiterCodeDynamique(html);
            contenu = html.getBytes(StandardCharsets.UTF_8);
          }

          if (gzip) {
            contenu = compresserGzip(contenu);
          }

          String reponse = "HTTP/1.1 200 OK\r\n";
          reponse += "Date: " + dateHttp() + "\r\n";
          reponse += "Server: MiniJavaServer\r\n";
          reponse += "Content-Type: " + trouverContentType(fichierDemande) + "\r\n";

          if (gzip) {
            reponse += "Content-Encoding: gzip\r\n";
          }

          reponse += "ETag: " + calculerEtag(fichierDemande) + "\r\n";
          reponse += "Last-Modified: " + dateModificationHttp(fichierDemande) + "\r\n";
          reponse += "Content-Length: " + contenu.length + "\r\n";
          reponse += "\r\n";

          sortie.write(reponse.getBytes());
          sortie.write(contenu);

          WebLogger.logAcces(config.getCheminLog(), client.getInetAddress() + " " + chemindDemande + " 200");
        } else {
          String message = "<html><body><h1>404 Not Found</h1></body></html>";
          String reponse = "HTTP/1.1 404 Not Found\r\n";
          reponse += "Date: " + dateHttp() + "\r\n";
          reponse += "Server: MiniJavaServer\r\n";
          reponse += "Content-Type: text/html\r\n";
          reponse += "Content-Length: " + message.length() + "\r\n";
          reponse += "\r\n";
          reponse += message;

          sortie.write(reponse.getBytes());

          WebLogger.logError(config.getCheminLogErreur(), client.getInetAddress() + " " + chemindDemande + " 404 fichier introuvable");
        }
        client.close();
      }

    } catch (Exception e) {
      System.out.println("Erreur survenu sur le port " + config.getPort() + " : " + e.getMessage());
    }
  }

  public static String trouverContentType(File fichier ){
    String nom = fichier.getName().toLowerCase();

    if (nom.endsWith(".html") || nom.endsWith(".htm")) {
      return "text/html";
    } else if (nom.endsWith(".css")) {
      return "text/css";
    } else if (nom.endsWith(".js")) {
      return "application/javascript";
    } else if (nom.endsWith(".jpg") || nom.endsWith(".jpeg")) {
      return "image/jpeg";
    } else if (nom.endsWith(".png")) {
      return "image/png";
    } else if (nom.endsWith(".gif")) {
      return "image/gif";
    } else if (nom.endsWith(".pdf")) {
      return "application/pdf";
    } else {
      return "application/octet-stream";
    }
  }
  public static String dateHttp()  {
    return DateTimeFormatter.RFC_1123_DATE_TIME.format(ZonedDateTime.now());
  }

  public static String genererListeDossier(File dossier, String cheminDemande) {
    String html = "<html><body>";
    html += "<h1>Liste du dossier : " + cheminDemande + "</h1>";
    html += "<ul>";

    File[] fichiers = dossier.listFiles();

    if (fichiers != null) {
      for (File fichier : fichiers ) {
        String nom = fichier.getName();
        String lien = cheminDemande;

        if (!lien.endsWith("/")) {
          lien += "/";
        }
        lien += nom;

        if (fichier.isDirectory()) {
          lien += "/";
          nom += "/";
        }

        html += "<li><a href=\"" + lien + "\">" + nom + "</a></li>";
      }
    }

    html += "</ul>";
    html += "</body></html>";

    return html;
  }

  public static String calculerEtag(File fichier) {
    try {
      String texte = fichier.getPath() + fichier.length() + fichier.lastModified();

      MessageDigest md = MessageDigest.getInstance("SHA-1");
      byte[] hash = md.digest(texte.getBytes());

      String resultat = "";
      for (byte b : hash) {
        resultat += String.format("%02x",b);
      }

      return "\"" + resultat + "\"";
    } catch(Exception e) {
      return "\"" + fichier.length() + "-" + fichier.lastModified() + "\"";
    }
  }

  public static String dateModificationHttp(File fichier) {
    Instant instant = Instant.ofEpochMilli(fichier.lastModified());
    ZonedDateTime date = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault());
    return DateTimeFormatter.RFC_1123_DATE_TIME.format(date);
  }

  public static boolean fichierNonModifie(File fichier, String dateClient) {
    try {
      ZonedDateTime date = ZonedDateTime.parse(dateClient, DateTimeFormatter.RFC_1123_DATE_TIME);
      long tempsClient = date.toInstant().toEpochMilli();
      long tempsFichier = fichier.lastModified();
      return tempsFichier / 1000 <= tempsClient / 1000;
    } catch (Exception e) {
      return false;
    }
  }

  public static boolean doitGzip(File fichier) {
    String nom = fichier.getName().toLowerCase();

    return nom.endsWith(".png") || nom.endsWith(".jpg")|| nom.endsWith(".jpeg") ||
    nom.endsWith(".pdf");
  }

  public static byte[] compresserGzip(byte[] contenu) {
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      GZIPOutputStream gzip = new GZIPOutputStream(baos);

      gzip.write(contenu);
      gzip.close();

      return baos.toByteArray();
    } catch (Exception e) {
      return contenu;
    }
  }

  public static boolean estHtml(File fichier) {
    String nom = fichier.getName().toLowerCase();
    return nom.endsWith(".html") || nom.endsWith(".htm");
  }

  public static String executerCode(String interpreteur, String code) {
    try {
      ProcessBuilder pb = new ProcessBuilder(interpreteur, "-c", code);
      Process p = pb.start();

      byte[] resultat = p.getInputStream().readAllBytes();
      byte[] erreurs = p.getErrorStream().readAllBytes();

      p.waitFor();

      if (resultat.length > 0) {
        return new String(resultat);
      }

      if (erreurs.length > 0) {
        return new String(erreurs);
      }

      return "";

    } catch (Exception e) {
        return "[erreur execution]";
    }
  }

  public static String traiterCodeDynamique(String html) {
    String debutBalise = "<code interpreteur=\"";
    String finalBalise = "</code>";

    int debut = html.indexOf(debutBalise);

    while(debut != -1) {
      int debutInterpreteur = debut + debutBalise.length();
      int finInterpreteur = html.indexOf("\"", debutInterpreteur);

      int finOuverture = html.indexOf(">", finInterpreteur);
      int finCode = html.indexOf(finalBalise, finOuverture);

      if(finInterpreteur == -1 || finOuverture == -1 || finCode == -1) {
        break;
      }

      String interpreteur = html.substring(debutInterpreteur, finInterpreteur);
      String code = html.substring(finOuverture + 1, finCode);

      String resultat = executerCode(interpreteur, code);

      String avant = html.substring(0,debut);
      String apres = html.substring(finCode + finalBalise.length());

      html = avant + resultat + apres;

      debut = html.indexOf(debutBalise);
    }
    return html;
  }
  public static void creerPid() {
    try {
      String home = System.getProperty("user.home");
      File dossierRun = new File(home + "/serveurWeb/run");

      if (!dossierRun.exists()) {
        dossierRun.mkdirs();
      }

      long pid = ProcessHandle.current().pid();

      FileWriter fw = new FileWriter(home + "/serveurWeb/run/myweb.pid");
      fw.write(String.valueOf(pid));
      fw.close();

      System.out.println("PID écrit : " + pid);

    } catch (Exception e ) {
      System.out.println("Erreur création PID : " + e.getMessage());
    }
  }
}

